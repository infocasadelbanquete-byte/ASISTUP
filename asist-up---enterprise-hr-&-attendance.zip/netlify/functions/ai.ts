import { GoogleGenAI } from "@google/genai";

const getServerEnv = (): Record<string, string | undefined> => {
  const proc = (globalThis as unknown as { process?: { env?: Record<string, string | undefined> } }).process;
  return proc?.env ?? {};
};

export default async (req: Request): Promise<Response> => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { "Content-Type": "application/json" }
    });
  }

  try {
    const body = (await req.json()) as {
      prompt?: string;
      activeEmps?: number;
      totalPayments?: number;
      attendanceCount?: number;
    };

    const userPrompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
    if (!userPrompt) {
      return new Response(JSON.stringify({ error: "Prompt requerido" }), {
        status: 400,
        headers: { "Content-Type": "application/json" }
      });
    }

    const env = getServerEnv();
    const apiKey = env.GEMINI_API_KEY || env.VITE_GEMINI_API_KEY || "";
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: "GEMINI_API_KEY no configurada en el entorno del servidor." }),
        { status: 500, headers: { "Content-Type": "application/json" } }
      );
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });

    const activeEmps = Number(body.activeEmps) || 0;
    const totalPayments = Number(body.totalPayments) || 0;
    const attendanceCount = Number(body.attendanceCount) || 0;

    const context = `
Eres un consultor experto en Talento Humano y legislación laboral ecuatoriana.
Contexto de la empresa actual:
- Colaboradores activos: ${activeEmps}
- Total nómina procesada este mes: $${totalPayments.toFixed(2)}
- Registros de asistencia totales: ${attendanceCount}

Pregunta del administrador: ${userPrompt}
    `.trim();

    const response = await ai.models.generateContent({
      model: "gemini-4-hydrogen",
      contents: context,
      config: {
        systemInstruction:
          "Proporciona respuestas profesionales, concisas y basadas en mejores prácticas de RRHH en Ecuador. Si la pregunta es sobre leyes ecuatorianas, menciona que es una guía general."
      }
    });

    return new Response(
      JSON.stringify({ text: response.text || "No pude generar una respuesta en este momento." }),
      {
        status: 200,
        headers: { "Content-Type": "application/json" }
      }
    );
  } catch (error) {
    console.error("Server Gemini Error:", error);
    return new Response(
      JSON.stringify({ error: "Error al procesar la consulta con el servicio de IA." }),
      {
        status: 500,
        headers: { "Content-Type": "application/json" }
      }
    );
  }
};
